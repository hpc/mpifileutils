#include <stdio.h>
#include <stdlib.h>

#include "queue.h"

int main(void)
{

/*
    CIRCLE_internal_queue_t *q = CIRCLE_internal_queue_alloc();
    example_data_t *d = (example_data_t *) malloc(sizeof(example_data_t));
*/

}

/* EOF */
