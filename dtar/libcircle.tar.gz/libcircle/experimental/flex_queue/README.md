This is an experimental data structure to prepare for a more flexible item
type for libcircle queue items.
